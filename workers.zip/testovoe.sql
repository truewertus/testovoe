-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.50 - MySQL Community Server (GPL)
-- ОС Сервера:                   Win64
-- HeidiSQL Версия:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры базы данных workers
CREATE DATABASE IF NOT EXISTS `workers` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `workers`;


-- Дамп структуры для таблица workers.sub
CREATE TABLE IF NOT EXISTS `sub` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `deleted` int(10) unsigned DEFAULT NULL,
  `name` text,
  PRIMARY KEY (`id`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы workers.sub: ~13 rows (приблизительно)
DELETE FROM `sub`;
/*!40000 ALTER TABLE `sub` DISABLE KEYS */;
INSERT INTO `sub` (`id`, `deleted`, `name`) VALUES
	(1, 0, 'Подразделение 1'),
	(2, 0, 'Подразделение 2'),
	(3, 1, 'Подразделение 3'),
	(4, 1, '123'),
	(5, 1, 'Привет'),
	(6, 1, 'как дела все хорошо'),
	(7, 1, '123'),
	(8, 1, '123'),
	(9, 1, '123'),
	(10, 1, '123'),
	(11, 1, 'аафыва'),
	(12, 1, 'афыва'),
	(13, 1, '123'),
	(14, 0, 'Подразделение 3');
/*!40000 ALTER TABLE `sub` ENABLE KEYS */;


-- Дамп структуры для таблица workers.workers
CREATE TABLE IF NOT EXISTS `workers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `surname` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `secondname` varchar(100) DEFAULT NULL,
  `bdate` date DEFAULT NULL,
  `subid` int(10) unsigned NOT NULL,
  `deleted` int(10) unsigned NOT NULL,
  `pol` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы workers.workers: ~1 rows (приблизительно)
DELETE FROM `workers`;
/*!40000 ALTER TABLE `workers` DISABLE KEYS */;
INSERT INTO `workers` (`id`, `surname`, `name`, `secondname`, `bdate`, `subid`, `deleted`, `pol`) VALUES
	(1, 'Иванов', 'Иван', 'Иванович', '1999-10-01', 1, 0, 1),
	(2, 'Тестов', 'Тест', 'Тестович', '2020-01-02', 1, 0, 1),
	(3, 'Еще', 'тест', 'тест', '0000-00-00', 14, 0, 1);
/*!40000 ALTER TABLE `workers` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
